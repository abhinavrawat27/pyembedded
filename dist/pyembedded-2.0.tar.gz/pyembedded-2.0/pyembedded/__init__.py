# Version of module

__version__ = 2.0
