# Version of module

__version__ = 3.1
